clc;
clear;

dataName = {'instances1/D01.txt'; 'instances1/D02.txt'; 'instances1/D03.txt'; 'instances1/D04.txt'; 'instances1/D05.txt';
    'instances2/R01.txt'; 'instances2/R02.txt'; 'instances2/R03.txt'; 'instances2/R04.txt'; 'instances2/R05.txt';
    'instances2/R06.txt'; 'instances2/R07.txt'; 'instances2/R08.txt';
    'instances3/FMK01.txt'; 'instances3/FMK02.txt'; 'instances3/FMK03.txt'; 'instances3/FMK04.txt'; 'instances3/FMK05.txt';
    'instances3/FMK06.txt'; 'instances3/FMK07.txt'; 'instances3/FMK08.txt'; 'instances3/FMK09.txt'; 'instances3/FMK10.txt'};

%%% 定义可靠性模糊数库 (TFN)
% Format: [b1, b2, b3]
B_Medium    = [0.50, 0.60, 0.70];
B_High      = [0.60, 0.75, 0.90];
B_VeryHigh  = [0.80, 0.90, 1.00];
B_Perfect   = [0.90, 1.00, 1.00];

for i = 1:length(dataName)
    % 读取数据
    lines = readlines(dataName{i});  % 每行变成 string 数组
    T = cell(size(lines));

    for j = 1:length(lines)
        T{j} = str2num(lines(j));  % 转换成数字向量
    end

    % 打开文件
    if i <= 5
        fid = fopen(['Z-D0', num2str(i), '.txt'], 'w');  % 'w' 覆盖写，'a' 是追加写
    elseif i <= 13
        fid = fopen(['Z-R0', num2str(i-5), '.txt'], 'w');  % 'w' 覆盖写，'a' 是追加写
    elseif i <= 22
        fid = fopen(['Z-FMK0', num2str(i-13), '.txt'], 'w');  % 'w' 覆盖写，'a' 是追加写
    else
        fid = fopen('Z-FMK10.txt', 'w');  % 'w' 覆盖写，'a' 是追加写
    end
    fprintf(fid, '%d %d %d\r\n', T{1});  % 每行写入并换行

    N = T{1}(1);   % 工件数量
    M = T{1}(2);   % 机器数量

    %%% 定义机器分级 (随机打乱)
    rand_order = randperm(M);
    tier1_num = floor(0.2 * M); % 20% 精密/新机器
    tier2_num = floor(0.5 * M); % 50% 标准机器
    % 剩余为老化机器

    machine_tier = zeros(M, 1);
    machine_tier(rand_order(1:tier1_num)) = 1;
    machine_tier(rand_order(tier1_num+1:tier1_num+tier2_num)) = 2;
    machine_tier(rand_order(tier1_num+tier2_num+1:end)) = 3;

    for j = 2:length(T)-1
        FT = T{j};
        fprintf(fid,'%d   ', FT(1));     %工序数量，一个数据三个空格
        idx = 2;
        for k = 1:FT(1)
            avlMac = FT(idx);
            fprintf(fid,'%d   ', avlMac);
            idx = idx + 1;
            for m = 1:avlMac
                % 根据 Tier 随机选择 Reliability
                macNo = FT(idx);
                tier = machine_tier(macNo);
                r = rand();
                if tier == 1 % Tier 1: VeryHigh or Perfect
                    if r > 0.5, val = B_Perfect; else, val = B_VeryHigh; end
                elseif tier == 2 % Tier 2: High or VeryHigh
                    if r > 0.5, val = B_VeryHigh; else, val = B_High; end
                else % Tier 3: Medium or High
                    if r > 0.5, val = B_High; else, val = B_Medium; end
                end
                fprintf(fid,'%d %d %d %d ', FT(idx:idx+3));
                fprintf(fid,'%.2f %.2f %.2f   ', val);
                idx = idx + 4;
            end
        end
        fprintf(fid, '\r\n');    %写完一个之后换行
    end

    % 关闭文件
    fclose(fid);

end