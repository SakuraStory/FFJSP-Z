clc;
clear;

dataName = {'data1.xlsx'; 'data2.xlsx'; 'data3.xlsx'; 'data4.xlsx'; 'data5.xlsx'};
jobAndMach = [10, 10, 0;
              10, 10, 0;
              10, 10, 0;
              10, 10, 0;
              15, 10, 0];   % 每个实例的工件数和机器数
opNum = {[4; 4; 4; 4; 4; 4; 4; 4; 4; 4];
         [4; 4; 4; 4; 4; 4; 4; 4; 4; 4];
         [4; 6; 4; 6; 5; 5; 5; 5; 5; 5];
         [4; 6; 4; 6; 5; 5; 5; 5; 5; 5];
         [5; 6; 5; 6; 5; 5; 5; 5; 5; 5; 6; 6; 6; 5; 5]};

for i = 1:length(dataName)
    % 打开文件
    fid = fopen(['D0', num2str(i), '.txt'], 'w');  % 'w' 覆盖写，'a' 是追加写
    fprintf(fid, '%d %d %d\r\n', jobAndMach(i, :));  % 每行写入并换行

    T = readmatrix(dataName{i});
    H = opNum{i};
    N = jobAndMach(i, 1);   % 工件数量
    M = jobAndMach(i, 2);   % 机器数量
    opIdx = 1;

    for j = 1:N
        fprintf(fid,'%d   ',H(j));%一个数据三个空格
        for k = 1:H(j)
            %%% 每个工序都可以在任意台机器上加工
            fprintf(fid,'%d   ', M);
            FT = T(opIdx, :);
            for m = 1:M
                fprintf(fid,'%d %d %d %d   ', [m, FT((m-1)*3+1:m*3)]);
            end
            opIdx = opIdx + 1;
        end
        fprintf(fid, '\r\n');    %写完一个之后换行
    end

    % 关闭文件
    fclose(fid);

end