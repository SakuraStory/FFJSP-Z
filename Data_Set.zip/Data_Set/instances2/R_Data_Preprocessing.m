clc;
clear;

dataName = {'remanu01.txt'; 'remanu02.txt'; 'remanu03.txt'; 'remanu04.txt'; 'remanu05.txt'; 'remanu06.txt'; 'remanu07.txt'; 'remanu08.txt'};

for i = 1:length(dataName)
    % 读取数据
    lines = readlines(dataName{i});  % 每行变成 string 数组
    T = cell(size(lines));
    
    for j = 1:length(lines)
        T{j} = str2num(lines(j));  % 转换成数字向量
    end

    % 打开文件
    fid = fopen(['R0', num2str(i), '.txt'], 'w');  % 'w' 覆盖写，'a' 是追加写
    fprintf(fid, '%d %d %d\r\n', T{1});  % 每行写入并换行

    N = T{1}(1);   % 工件数量
    M = T{1}(2);   % 机器数量

    for j = 2:length(T)-1
        FT = T{j};
        fprintf(fid,'%d   ',FT(1));     %工序数量，一个数据三个空格
        idx = 2;
        for k = 1:FT(1)
            avlMac = FT(idx);
            fprintf(fid,'%d   ', avlMac);
            idx = idx + 1;
            for m = 1:avlMac
                fprintf(fid,'%d %d %d %d   ', FT(idx:idx+3));
                idx = idx + 4;
            end
        end
        fprintf(fid, '\r\n');    %写完一个之后换行
    end

    % 关闭文件
    fclose(fid);

end